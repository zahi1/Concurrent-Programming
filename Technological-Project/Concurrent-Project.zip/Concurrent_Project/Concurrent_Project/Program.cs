﻿using System;
using System.IO;
using System.Linq;
using System.Diagnostics;

class ParallelParagraphCounter
{
    static void Main(string[] args)
    {
        string filePath = args.Length > 0 ? args[0] : @"C:\Users\helou\source\repos\Concurrent_Project\Concurrent_Project\datafile8.txt";

        Console.WriteLine("Enter the maximum degree of parallelism (-1 for unlimited or a positive integer): ");
        if (!int.TryParse(Console.ReadLine(), out int maxDegreeOfParallelism) || maxDegreeOfParallelism < -1)
        {
            Console.WriteLine("Invalid input. Using default value: -1 (unlimited)");
            maxDegreeOfParallelism = -1;
        }

        try
        {
            string[] lines = File.ReadAllLines(filePath);

            var stopwatch = Stopwatch.StartNew();

            var lineQuery = lines.AsParallel();
            if (maxDegreeOfParallelism != -1)
            {
                lineQuery = lineQuery.WithDegreeOfParallelism(maxDegreeOfParallelism);
            }

            var isBoundary = lineQuery.Select(line => string.IsNullOrWhiteSpace(line))
                                      .ToArray();

            int paragraphCount = CountParagraphs(isBoundary);

            stopwatch.Stop();

            Console.WriteLine($"Number of paragraphs: {paragraphCount}");
            Console.WriteLine($"Time taken: {stopwatch.ElapsedMilliseconds} ms");
        }
        catch (IOException e)
        {
            Console.WriteLine($"An error occurred while reading the file: {e.Message}");
        }
    }

    static int CountParagraphs(bool[] isBoundary)
    {
        int paragraphCount = 0;
        bool inParagraph = false;

        foreach (var boundary in isBoundary)
        {
            if (boundary)
            {
                if (inParagraph)
                {
                    paragraphCount++;
                    inParagraph = false;
                }
            }
            else
            {
                inParagraph = true;
            }
        }

        if (inParagraph)
        {
            paragraphCount++;
        }

        return paragraphCount;
    }
}